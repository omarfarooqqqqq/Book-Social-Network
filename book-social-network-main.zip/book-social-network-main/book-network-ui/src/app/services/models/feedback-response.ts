/* tslint:disable */
/* eslint-disable */
export interface FeedbackResponse {
  comment?: string;
  note?: number;
  ownFeedback?: boolean;
}
