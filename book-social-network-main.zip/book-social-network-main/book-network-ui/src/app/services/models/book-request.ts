/* tslint:disable */
/* eslint-disable */
export interface BookRequest {
  authorName: string;
  id?: number;
  isbn: string;
  shareable?: boolean;
  synopsis: string;
  title: string;
}
