/* tslint:disable */
/* eslint-disable */
export interface FeedbackRequest {
  bookId: number;
  comment: string;
  note?: number;
}
